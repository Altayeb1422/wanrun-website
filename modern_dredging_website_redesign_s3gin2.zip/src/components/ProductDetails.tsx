import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { 
  ChevronRight, 
  Download,
  Check,
  Play,
  X,
  Mail,
  Phone,
  MessageCircle,
  FileText,
  Image as ImageIcon,
  Info,
  ArrowRight,
  Tag,
  Gauge,
  Ruler,
  Power,
  Waves
} from 'lucide-react';

interface Specification {
  name: string;
  value: string;
}

interface Feature {
  title: string;
  description: string;
  icon: JSX.Element;
}

interface Document {
  name: string;
  size: string;
}

const ProductDetails: React.FC = () => {
  const { id } = useParams();
  const [activeImage, setActiveImage] = useState(0);
  const [activeTab, setActiveTab] = useState('specifications');
  const [showInquiryForm, setShowInquiryForm] = useState(false);

  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  // Sample product data - replace with actual data
  const product = {
    id: 1,
    name: "CSD750 Cutter Suction Dredger",
    description: "High-performance cutter suction dredger with advanced features for optimal dredging operations.",
    price: "Contact for Price",
    images: [
      "https://images.unsplash.com/photo-1635347319127-27c24b3b0bab?auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1581094794329-c8112c4e5190?auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1577592143361-cf57b38fa56d?auto=format&fit=crop&q=80"
    ],
    specifications: [
      { name: "Dredging Depth", value: "25 meters" },
      { name: "Pipeline Diameter", value: "750mm" },
      { name: "Total Power", value: "2000kW" },
      { name: "Production Capacity", value: "3000m³/h" },
      { name: "Length", value: "50 meters" },
      { name: "Width", value: "10 meters" },
      { name: "Draft", value: "2.5 meters" },
      { name: "Fuel Capacity", value: "10000L" }
    ],
    features: [
      {
        title: "Advanced Control System",
        description: "Integrated digital control system for precise operation",
        icon: <Info className="h-6 w-6" />
      },
      {
        title: "Eco-Friendly Design",
        description: "Reduced emissions and improved fuel efficiency",
        icon: <Info className="h-6 w-6" />
      },
      {
        title: "Remote Monitoring",
        description: "Real-time performance tracking and diagnostics",
        icon: <Info className="h-6 w-6" />
      }
    ],
    documents: [
      { name: "Technical Specifications", size: "2.5 MB" },
      { name: "Operation Manual", size: "3.1 MB" },
      { name: "Maintenance Guide", size: "1.8 MB" }
    ],
    tags: ["Heavy Duty", "High Capacity", "Deep Dredging"],
    rating: 5
  };

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowInquiryForm(false);
  };

  const SpecIcon = ({ type }: { type: string }) => {
    switch (type) {
      case 'power':
        return <Power className="h-4 w-4" />;
      case 'depth':
        return <Ruler className="h-4 w-4" />;
      case 'capacity':
        return <Gauge className="h-4 w-4" />;
      case 'diameter':
        return <Waves className="h-4 w-4" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center overflow-hidden bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-blue-900/30 backdrop-blur-sm"></div>
          <motion.div
            style={{ opacity }}
            className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[length:20px_20px]"
          ></motion.div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl lg:text-7xl font-bold text-white mb-6 leading-tight">
                {product.name}
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                {product.description}
              </p>
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => setShowInquiryForm(true)}
                  className="px-8 py-4 bg-white text-blue-900 rounded-lg font-medium hover:bg-blue-50 transition-all transform hover:scale-105 flex items-center"
                >
                  Request Quote
                  <ArrowRight className="inline-block ml-2" />
                </button>
                <button className="px-8 py-4 border-2 border-white text-white rounded-lg font-medium hover:bg-white hover:text-blue-900 transition-all transform hover:scale-105 flex items-center">
                  <Download className="h-5 w-5 mr-2" />
                  Download Brochure
                </button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative hidden lg:block"
            >
              <div className="relative w-full h-[500px]">
                <motion.div
                  animate={{
                    y: [0, -20, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0"
                >
                  <img
                    src={product.images[activeImage]}
                    alt={product.name}
                    className="w-full h-full object-cover rounded-2xl shadow-2xl"
                  />
                </motion.div>
                <motion.div
                  animate={{
                    y: [0, 20, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5
                  }}
                  className="absolute -bottom-10 -left-10 w-48 h-48 bg-blue-500 rounded-2xl opacity-20"
                ></motion.div>
                <motion.div
                  animate={{
                    y: [0, -15, 0],
                  }}
                  transition={{
                    duration: 3.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                  }}
                  className="absolute -top-10 -right-10 w-32 h-32 bg-blue-300 rounded-full opacity-20"
                ></motion.div>
              </div>
            </motion.div>
          </div>
        </div>
        <motion.div
          style={{ y }}
          className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-50 to-transparent"
        ></motion.div>
      </section>

      {/* Product Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div>
            <div className="grid grid-cols-3 gap-4 mb-4">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setActiveImage(index)}
                  className={`relative aspect-video rounded-lg overflow-hidden ${
                    activeImage === index ? 'ring-2 ring-blue-500' : ''
                  }`}
                >
                  <img
                    src={image}
                    alt={`${product.name} view ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="flex flex-wrap gap-2 mb-4">
              {product.tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                >
                  <Tag className="h-3 w-3 mr-1" />
                  {tag}
                </span>
              ))}
            </div>
            <div className="bg-gray-100 rounded-lg p-6 mb-8">
              <h3 className="text-lg font-semibold mb-4">Quick Specifications</h3>
              <div className="grid grid-cols-2 gap-4">
                {product.specifications.slice(0, 4).map((spec) => (
                  <div key={spec.name}>
                    <div className="text-sm text-gray-600">{spec.name}</div>
                    <div className="font-medium">{spec.value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Key Features */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Key Features</h3>
              <div className="space-y-4">
                {product.features.map((feature) => (
                  <div key={feature.title} className="flex items-start">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center text-blue-900">
                      {feature.icon}
                    </div>
                    <div className="ml-4">
                      <h4 className="font-medium">{feature.title}</h4>
                      <p className="text-gray-600">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Information Tabs */}
        <div className="mt-16">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8">
              {['specifications', 'documents', 'videos'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab
                      ? 'border-blue-900 text-blue-900'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </nav>
          </div>

          <div className="py-8">
            {activeTab === 'specifications' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {product.specifications.map((spec) => (
                  <div key={spec.name} className="flex justify-between py-3 border-b">
                    <span className="text-gray-600">{spec.name}</span>
                    <span className="font-medium">{spec.value}</span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'documents' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {product.documents.map((doc) => (
                  <div key={doc.name} className="flex items-center justify-between p-4 bg-white rounded-lg border">
                    <div className="flex items-center">
                      <FileText className="h-6 w-6 text-gray-400" />
                      <div className="ml-3">
                        <div className="font-medium">{doc.name}</div>
                        <div className="text-sm text-gray-500">{doc.size}</div>
                      </div>
                    </div>
                    <button className="text-blue-900 hover:text-blue-700">
                      <Download className="h-5 w-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'videos' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
                  <Play className="h-12 w-12 text-gray-400" />
                </div>
                <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
                  <Play className="h-12 w-12 text-gray-400" />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Inquiry Form Modal */}
      {showInquiryForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-lg max-w-md w-full p-6"
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Product Inquiry</h3>
              <button
                onClick={() => setShowInquiryForm(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <form onSubmit={handleInquirySubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Message
                </label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full px-6 py-3 bg-blue-900 text-white font-medium rounded-lg hover:bg-blue-800 transition-colors"
              >
                Send Inquiry
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default ProductDetails;
