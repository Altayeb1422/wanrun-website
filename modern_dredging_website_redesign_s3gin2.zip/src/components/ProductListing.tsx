import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Filter,
  ChevronRight,
  X,
  Tag,
  ArrowRight,
  Download,
  Eye,
  Mail,
  Star,
  Gauge,
  Ruler,
  Power,
  Waves
} from 'lucide-react';

interface Product {
  id: number;
  name: string;
  category: string;
  type: string;
  image: string;
  description: string;
  specifications: {
    power?: string;
    depth?: string;
    capacity?: string;
    diameter?: string;
  };
  featured: boolean;
  tags: string[];
  rating: number;
}

const products: Product[] = [
  {
    id: 1,
    name: "CSD750 Cutter Suction Dredger",
    category: "Cutter Suction Dredgers",
    type: "Heavy Duty",
    image: "https://images.unsplash.com/photo-1635347319127-27c24b3b0bab?auto=format&fit=crop&q=80",
    description: "High-performance cutter suction dredger for demanding projects",
    specifications: {
      power: "2000kW",
      depth: "25m",
      capacity: "3000m³/h",
      diameter: "750mm"
    },
    featured: true,
    tags: ["Heavy Duty", "High Capacity", "Deep Dredging"],
    rating: 5
  },
  {
    id: 2,
    name: "TSD450 Trailing Suction Dredger",
    category: "Trailing Suction Dredgers",
    type: "Standard",
    image: "https://images.unsplash.com/photo-1581094794329-c8112c4e5190?auto=format&fit=crop&q=80",
    description: "Versatile trailing suction dredger for various applications",
    specifications: {
      power: "1500kW",
      depth: "20m",
      capacity: "2000m³/h",
      diameter: "450mm"
    },
    featured: false,
    tags: ["Standard", "Versatile", "Efficient"],
    rating: 4
  }
];

const categories = ["All", "Cutter Suction Dredgers", "Trailing Suction Dredgers", "Backhoe Dredgers"];
const types = ["All", "Heavy Duty", "Standard", "Compact"];

const SpecIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'power':
      return <Power className="h-4 w-4" />;
    case 'depth':
      return <Ruler className="h-4 w-4" />;
    case 'capacity':
      return <Gauge className="h-4 w-4" />;
    case 'diameter':
      return <Waves className="h-4 w-4" />;
    default:
      return null;
  }
};

const ProductListing: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedType, setSelectedType] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("featured");
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);

  useEffect(() => {
    let result = products;

    if (selectedCategory !== "All") {
      result = result.filter(product => product.category === selectedCategory);
    }

    if (selectedType !== "All") {
      result = result.filter(product => product.type === selectedType);
    }

    if (searchQuery) {
      result = result.filter(product => 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case "featured":
          return Number(b.featured) - Number(a.featured);
        case "name-asc":
          return a.name.localeCompare(b.name);
        case "name-desc":
          return b.name.localeCompare(a.name);
        default:
          return 0;
      }
    });

    setFilteredProducts(result);
  }, [selectedCategory, selectedType, searchQuery, sortBy]);

  const handleResetFilters = () => {
    setSelectedCategory("All");
    setSelectedType("All");
    setSearchQuery("");
    setSortBy("featured");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center overflow-hidden bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-blue-900/30 backdrop-blur-sm"></div>
          <motion.div
            style={{ opacity }}
            className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[length:20px_20px]"
          ></motion.div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl lg:text-7xl font-bold text-white mb-6 leading-tight">
                Explore Our
                <span className="text-blue-400"> Dredging Equipment</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Discover our comprehensive range of high-performance dredging solutions engineered for excellence.
              </p>
              <div className="flex flex-wrap gap-4">
                <button className="px-8 py-4 bg-white text-blue-900 rounded-lg font-medium hover:bg-blue-50 transition-all transform hover:scale-105 flex items-center">
                  <Download className="h-5 w-5 mr-2" />
                  Download Catalog
                </button>
                <button className="px-8 py-4 border-2 border-white text-white rounded-lg font-medium hover:bg-white hover:text-blue-900 transition-all transform hover:scale-105 flex items-center">
                  <Mail className="h-5 w-5 mr-2" />
                  Request Quote
                </button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative hidden lg:block"
            >
              <div className="relative w-full h-[500px]">
                <motion.div
                  animate={{
                    y: [0, -20, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0"
                >
                  <img
                    src="https://images.unsplash.com/photo-1577592143361-cf57b38fa56d?auto=format&fit=crop&q=80"
                    alt="Dredging Equipment"
                    className="w-full h-full object-cover rounded-2xl shadow-2xl"
                  />
                </motion.div>
                <motion.div
                  animate={{
                    y: [0, 20, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5
                  }}
                  className="absolute -bottom-10 -left-10 w-48 h-48 bg-blue-500 rounded-2xl opacity-20"
                ></motion.div>
                <motion.div
                  animate={{
                    y: [0, -15, 0],
                  }}
                  transition={{
                    duration: 3.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                  }}
                  className="absolute -top-10 -right-10 w-32 h-32 bg-blue-300 rounded-full opacity-20"
                ></motion.div>
              </div>
            </motion.div>
          </div>
        </div>
        <motion.div
          style={{ y }}
          className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-50 to-transparent"
        ></motion.div>
      </section>

      {/* Search and Filters */}
      <div className="sticky top-20 z-10 bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="w-full md:w-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full md:w-80 pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === category
                      ? 'bg-blue-900 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredProducts.map((product) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="group bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition-all duration-300"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                  />
                  {product.featured && (
                    <div className="absolute top-4 left-4 bg-blue-900/90 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium">
                      Featured
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>

                <div className="p-6">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {product.tags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                      >
                        <Tag className="h-3 w-3 mr-1" />
                        {tag}
                      </span>
                    ))}
                  </div>

                  <h2 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-900 transition-colors">
                    {product.name}
                  </h2>
                  <p className="text-gray-600 mb-4 line-clamp-2">
                    {product.description}
                  </p>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="flex items-center space-x-2 bg-gray-50 p-2 rounded-lg">
                        <SpecIcon type={key} />
                        <div>
                          <div className="text-xs text-gray-500 capitalize">{key}</div>
                          <div className="font-medium text-gray-900">{value}</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex space-x-3">
                    <Link
                      to={`/products/${product.id}`}
                      className="flex-1 bg-blue-900 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-800 transition-colors flex items-center justify-center"
                    >
                      <Eye className="h-5 w-5 mr-2" />
                      View Details
                    </Link>
                    <button
                      className="flex-1 border border-blue-900 text-blue-900 px-4 py-2 rounded-lg font-medium hover:bg-blue-900 hover:text-white transition-colors flex items-center justify-center"
                    >
                      <Mail className="h-5 w-5 mr-2" />
                      Request Quote
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <div className="bg-white rounded-xl p-8 max-w-md mx-auto">
              <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No products found
              </h3>
              <p className="text-gray-600 mb-4">
                Try adjusting your search or filter criteria
              </p>
              <button
                onClick={handleResetFilters}
                className="text-blue-900 hover:text-blue-700 font-medium"
              >
                Clear all filters
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductListing;
