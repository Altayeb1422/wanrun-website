import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Facebook, 
  Twitter, 
  Linkedin, 
  Instagram, 
  Youtube,
  Mail,
  Phone,
  MapPin,
  ArrowRight,
  Globe,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface NewsletterState {
  status: 'idle' | 'loading' | 'success' | 'error';
  message: string;
}

const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [newsletterState, setNewsletterState] = useState<NewsletterState>({
    status: 'idle',
    message: ''
  });

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewsletterState({ status: 'loading', message: '' });

    // Simulate API call
    setTimeout(() => {
      if (email.includes('@')) {
        setNewsletterState({
          status: 'success',
          message: 'Thank you for subscribing to our newsletter!'
        });
        setEmail('');
      } else {
        setNewsletterState({
          status: 'error',
          message: 'Please enter a valid email address.'
        });
      }
    }, 1000);
  };

  const quickLinks = [
    { name: 'About Us', path: '/about' },
    { name: 'Products', path: '/products' },
    { name: 'Services', path: '/services' },
    { name: 'Projects', path: '/projects' },
    { name: 'News', path: '/news' },
    { name: 'Contact', path: '/contact' }
  ];

  const products = [
    { name: 'Cutter Suction Dredgers', path: '/products/cutter-suction-dredgers' },
    { name: 'Trailing Suction Dredgers', path: '/products/trailing-suction-dredgers' },
    { name: 'Backhoe Dredgers', path: '/products/backhoe-dredgers' },
    { name: 'Spare Parts', path: '/products/spare-parts' }
  ];

  const socialLinks = [
    { icon: <Facebook className="h-5 w-5" />, url: '#', name: 'Facebook' },
    { icon: <Twitter className="h-5 w-5" />, url: '#', name: 'Twitter' },
    { icon: <Linkedin className="h-5 w-5" />, url: '#', name: 'LinkedIn' },
    { icon: <Instagram className="h-5 w-5" />, url: '#', name: 'Instagram' },
    { icon: <Youtube className="h-5 w-5" />, url: '#', name: 'YouTube' }
  ];

  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="mb-4">
              <img 
                src="/logo-white.svg" 
                alt="Wan Run Dredging" 
                className="h-8"
              />
            </div>
            <p className="text-gray-400 mb-4">
              Leading manufacturer of dredging equipment with over 13 years of experience in delivering high-quality solutions worldwide.
            </p>
            <div className="space-y-2">
              <a href="mailto:info@wandredging.com" className="flex items-center hover:text-white transition-colors">
                <Mail className="h-5 w-5 mr-2" />
                info@wandredging.com
              </a>
              <a href="tel:+8612345678900" className="flex items-center hover:text-white transition-colors">
                <Phone className="h-5 w-5 mr-2" />
                +86 123 4567 8900
              </a>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-2 flex-shrink-0" />
                <span>Qingzhou, Shandong Province, China</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link 
                    to={link.path}
                    className="hover:text-white transition-colors flex items-center"
                  >
                    <ArrowRight className="h-4 w-4 mr-2" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Our Products</h3>
            <ul className="space-y-2">
              {products.map((product) => (
                <li key={product.name}>
                  <Link 
                    to={product.path}
                    className="hover:text-white transition-colors flex items-center"
                  >
                    <ArrowRight className="h-4 w-4 mr-2" />
                    {product.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Newsletter</h3>
            <p className="text-gray-400 mb-4">
              Subscribe to our newsletter for the latest updates and industry insights.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="space-y-4">
              <div>
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-blue-500 text-white"
                  />
                  <button
                    type="submit"
                    disabled={newsletterState.status === 'loading'}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-blue-500 hover:text-blue-400 disabled:opacity-50"
                  >
                    {newsletterState.status === 'loading' ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500" />
                    ) : (
                      <ArrowRight className="h-5 w-5" />
                    )}
                  </button>
                </div>
                {newsletterState.status === 'success' && (
                  <div className="flex items-center text-green-500 text-sm mt-2">
                    <CheckCircle className="h-4 w-4 mr-1" />
                    {newsletterState.message}
                  </div>
                )}
                {newsletterState.status === 'error' && (
                  <div className="flex items-center text-red-500 text-sm mt-2">
                    <AlertCircle className="h-4 w-4 mr-1" />
                    {newsletterState.message}
                  </div>
                )}
              </div>
            </form>
          </div>
        </div>

        {/* Social Links */}
        <div className="mt-8 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                  aria-label={social.name}
                >
                  {social.icon}
                </a>
              ))}
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="https://miningmachine.en.alibaba.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-gray-400 hover:text-white transition-colors"
              >
                <Globe className="h-5 w-5 mr-2" />
                Visit our Alibaba Store
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">
              © {new Date().getFullYear()} Wan Run Dredging. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm text-gray-400">
              <Link to="/privacy" className="hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="hover:text-white transition-colors">
                Terms of Service
              </Link>
              <Link to="/sitemap" className="hover:text-white transition-colors">
                Sitemap
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
