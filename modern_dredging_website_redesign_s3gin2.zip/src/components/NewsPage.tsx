import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Tag, ChevronRight, Search } from 'lucide-react';

interface NewsItem {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  image: string;
  category: string;
  tags: string[];
}

const newsData: NewsItem[] = [
  {
    id: 1,
    title: "New CSD750 Dredger Successfully Delivered to Nigeria",
    excerpt: "Major milestone achieved with the successful delivery and commissioning of our latest CSD750 dredger in Lagos.",
    content: "We are pleased to announce the successful delivery...",
    date: "2023-10-15",
    image: "https://images.unsplash.com/photo-1635347319127-27c24b3b0bab?auto=format&fit=crop&q=80",
    category: "Deliveries",
    tags: ["CSD750", "Africa", "Project Completion"]
  },
  {
    id: 2,
    title: "Wan Run Exhibits at WODCON XXIII",
    excerpt: "Showcasing our latest dredging innovations at the World Dredging Congress in Copenhagen.",
    content: "Wan Run Dredging made a significant impact...",
    date: "2023-09-28",
    image: "https://images.unsplash.com/photo-1591115765373-5207764f72e7?auto=format&fit=crop&q=80",
    category: "Events",
    tags: ["Exhibition", "Innovation", "Technology"]
  },
  {
    id: 3,
    title: "Environmental Award for Sustainable Dredging Practice",
    excerpt: "Recognition for our commitment to environmental protection in dredging operations.",
    content: "Our innovative approach to sustainable dredging...",
    date: "2023-09-15",
    image: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?auto=format&fit=crop&q=80",
    category: "Awards",
    tags: ["Environment", "Sustainability", "Recognition"]
  },
  {
    id: 4,
    title: "New R&D Center Opens in Qingzhou",
    excerpt: "State-of-the-art research facility to drive innovation in dredging technology.",
    content: "The new research and development center...",
    date: "2023-08-30",
    image: "https://images.unsplash.com/photo-1581094794329-c8112c4e5190?auto=format&fit=crop&q=80",
    category: "Company News",
    tags: ["R&D", "Innovation", "Facility"]
  }
];

const categories = ["All", "Deliveries", "Events", "Awards", "Company News"];

const NewsPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredNews = newsData.filter(news => {
    const matchesCategory = selectedCategory === "All" || news.category === selectedCategory;
    const matchesSearch = news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         news.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-gray-900 mb-4"
          >
            Latest News & Updates
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600"
          >
            Stay informed about our latest projects, achievements, and industry insights
          </motion.p>
        </div>

        {/* Filters and Search */}
        <div className="mb-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <motion.button
                key={category}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === category
                    ? 'bg-primary text-white'
                    : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
              >
                {category}
              </motion.button>
            ))}
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search news..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
        </div>

        {/* News Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredNews.map((news) => (
            <motion.article
              key={news.id}
              variants={itemVariants}
              className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={news.image}
                  alt={news.title}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute top-4 left-4">
                  <span className="inline-block bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-primary">
                    {news.category}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <Calendar className="h-4 w-4 mr-2" />
                  {new Date(news.date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-3">
                  {news.title}
                </h2>
                <p className="text-gray-600 mb-4">
                  {news.excerpt}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {news.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                    >
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </span>
                  ))}
                </div>
                <button className="inline-flex items-center text-primary hover:text-primary-dark font-medium">
                  Read More
                  <ChevronRight className="ml-1 h-4 w-4" />
                </button>
              </div>
            </motion.article>
          ))}
        </motion.div>

        {filteredNews.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <p className="text-gray-600 text-lg">
              No news articles found matching your criteria.
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default NewsPage;
