import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { 
  ArrowRight,
  ChevronRight,
  Shield,
  Globe,
  Award,
  Wrench,
  Anchor,
  Ship,
  Waves,
  Wind,
  CheckCircle,
  Settings,
  BarChart
} from 'lucide-react';

const HomePage: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const y = useTransform(scrollYProgress, [0, 0.2], [0, -100]);

  const fadeInUp = {
    initial: { opacity: 0, y: 60 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-blue-900/30 backdrop-blur-sm"></div>
          <motion.div
            style={{ opacity }}
            className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[length:20px_20px]"
          ></motion.div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl lg:text-7xl font-bold text-white mb-6 leading-tight">
                Leading the Future of
                <span className="text-blue-400"> Dredging Technology</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Innovative dredging solutions with over 13 years of excellence in manufacturing and global expertise.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/products"
                  className="px-8 py-4 bg-white text-blue-900 rounded-lg font-medium hover:bg-blue-50 transition-all transform hover:scale-105"
                >
                  Explore Products
                  <ArrowRight className="inline-block ml-2" />
                </Link>
                <Link
                  to="/contact"
                  className="px-8 py-4 border-2 border-white text-white rounded-lg font-medium hover:bg-white hover:text-blue-900 transition-all transform hover:scale-105"
                >
                  Contact Us
                  <ChevronRight className="inline-block ml-2" />
                </Link>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative hidden lg:block"
            >
              <div className="relative w-full h-[600px]">
                <motion.div
                  animate={{
                    y: [0, -20, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0"
                >
                  <img
                    src="https://images.unsplash.com/photo-1635347319127-27c24b3b0bab?auto=format&fit=crop&q=80"
                    alt="Dredging Equipment"
                    className="w-full h-full object-cover rounded-2xl shadow-2xl"
                  />
                </motion.div>
                <motion.div
                  animate={{
                    y: [0, 20, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5
                  }}
                  className="absolute -bottom-10 -left-10 w-48 h-48 bg-blue-500 rounded-2xl opacity-20"
                ></motion.div>
                <motion.div
                  animate={{
                    y: [0, -15, 0],
                  }}
                  transition={{
                    duration: 3.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                  }}
                  className="absolute -top-10 -right-10 w-32 h-32 bg-blue-300 rounded-full opacity-20"
                ></motion.div>
              </div>
            </motion.div>
          </div>
        </div>
        <motion.div
          style={{ y }}
          className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent"
        ></motion.div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
          >
            <div className="relative">
              <motion.div
                variants={fadeInUp}
                className="relative w-full h-[500px] rounded-2xl overflow-hidden"
              >
                <img
                  src="https://images.unsplash.com/photo-1581094794329-c8112c4e5190?auto=format&fit=crop&q=80"
                  alt="Dredging Operations"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-transparent"></div>
              </motion.div>
              <motion.div
                variants={fadeInUp}
                className="absolute -bottom-8 -right-8 bg-white p-6 rounded-xl shadow-xl"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <Award className="h-6 w-6 text-blue-900" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-900">13+</div>
                    <div className="text-gray-600">Years Experience</div>
                  </div>
                </div>
              </motion.div>
            </div>
            <motion.div variants={fadeInUp}>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Advanced Technology for Superior Performance
              </h2>
              <p className="text-gray-600 mb-8">
                Our cutting-edge dredging equipment combines innovative technology with robust engineering to deliver exceptional performance and reliability.
              </p>
              <div className="grid grid-cols-2 gap-6">
                {[
                  { icon: <Shield />, title: "Quality Assured", desc: "ISO 9001:2015 certified manufacturing" },
                  { icon: <Globe />, title: "Global Reach", desc: "Serving clients in 30+ countries" },
                  { icon: <Wrench />, title: "Expert Support", desc: "24/7 technical assistance" },
                  { icon: <Anchor />, title: "Custom Solutions", desc: "Tailored to your needs" }
                ].map((feature, index) => (
                  <motion.div
                    key={index}
                    variants={fadeInUp}
                    className="flex items-start space-x-4"
                  >
                    <div className="p-3 bg-blue-100 rounded-lg text-blue-900">
                      {feature.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{feature.title}</h3>
                      <p className="text-sm text-gray-600">{feature.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Products Showcase */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
          >
            <motion.div variants={fadeInUp} className="order-2 lg:order-1">
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Comprehensive Range of Dredging Equipment
              </h2>
              <p className="text-gray-600 mb-8">
                From powerful cutter suction dredgers to efficient trailing suction dredgers, we offer a complete range of equipment for all your dredging needs.
              </p>
              <div className="space-y-6">
                {[
                  { icon: <Ship />, title: "Cutter Suction Dredgers", desc: "Powerful and precise dredging operations" },
                  { icon: <Waves />, title: "Trailing Suction Dredgers", desc: "Efficient for large-scale projects" },
                  { icon: <Wind />, title: "Environmental Solutions", desc: "Eco-friendly dredging equipment" }
                ].map((product, index) => (
                  <motion.div
                    key={index}
                    variants={fadeInUp}
                    className="flex items-start space-x-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="p-3 bg-blue-100 rounded-lg text-blue-900">
                      {product.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{product.title}</h3>
                      <p className="text-sm text-gray-600">{product.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
              <motion.div variants={fadeInUp} className="mt-8">
                <Link
                  to="/products"
                  className="inline-flex items-center text-blue-900 font-medium hover:text-blue-700 transition-colors"
                >
                  View All Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </motion.div>
            </motion.div>
            <motion.div variants={fadeInUp} className="order-1 lg:order-2">
              <div className="relative">
                <motion.div
                  animate={{
                    rotate: [0, 5, -5, 0],
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="relative z-10"
                >
                  <img
                    src="https://images.unsplash.com/photo-1577592143361-cf57b38fa56d?auto=format&fit=crop&q=80"
                    alt="Product Showcase"
                    className="w-full h-[600px] object-cover rounded-2xl shadow-2xl"
                  />
                </motion.div>
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute -bottom-4 -right-4 w-64 h-64 bg-blue-200 rounded-full opacity-20"
                ></motion.div>
                <motion.div
                  animate={{
                    scale: [1, 0.9, 1],
                  }}
                  transition={{
                    duration: 5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute -top-4 -left-4 w-48 h-48 bg-blue-400 rounded-full opacity-20"
                ></motion.div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-blue-900 relative overflow-hidden">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute -right-64 -top-64 w-128 h-128 bg-blue-800 rounded-full opacity-20"
        ></motion.div>
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [360, 180, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute -left-64 -bottom-64 w-128 h-128 bg-blue-700 rounded-full opacity-20"
        ></motion.div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Transform Your Dredging Operations?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Contact us today to discuss your dredging equipment needs and discover how we can help optimize your operations.
            </p>
            <div className="flex justify-center space-x-4">
              <Link
                to="/contact"
                className="px-8 py-4 bg-white text-blue-900 rounded-lg font-medium hover:bg-blue-50 transition-all transform hover:scale-105"
              >
                Get in Touch
                <ArrowRight className="inline-block ml-2" />
              </Link>
              <Link
                to="/products"
                className="px-8 py-4 border-2 border-white text-white rounded-lg font-medium hover:bg-white hover:text-blue-900 transition-all transform hover:scale-105"
              >
                View Products
                <ChevronRight className="inline-block ml-2" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
