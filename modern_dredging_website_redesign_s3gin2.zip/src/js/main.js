import AOS from 'aos';
import 'aos/dist/aos.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

// Initialize AOS
AOS.init({
  duration: 800,
  offset: 100,
  once: true
});

// Navigation
const header = document.querySelector('[data-header]');
const nav = document.querySelector('[data-nav]');
const navToggle = document.querySelector('[data-nav-toggle]');
let lastScroll = 0;

navToggle?.addEventListener('click', () => {
  nav.classList.toggle('active');
  navToggle.classList.toggle('active');
});

window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset;
  
  if (currentScroll <= 0) {
    header.classList.remove('scrolled');
    header.classList.remove('visible');
  }
  
  if (currentScroll > lastScroll && currentScroll > 80) {
    header.classList.add('scrolled');
    header.classList.remove('visible');
  }
  
  if (currentScroll < lastScroll) {
    header.classList.remove('scrolled');
    header.classList.add('visible');
  }
  
  lastScroll = currentScroll;
});

// Stats Counter
const stats = document.querySelectorAll('[data-counter]');

const countUp = (element) => {
  const target = parseInt(element.dataset.counter);
  const count = parseInt(element.innerText);
  const increment = target / 200;
  
  if (count < target) {
    element.innerText = Math.ceil(count + increment);
    setTimeout(() => countUp(element), 1);
  } else {
    element.innerText = target;
  }
};

const observerCallback = (entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      countUp(entry.target);
    }
  });
};

const observer = new IntersectionObserver(observerCallback, {
  threshold: 0.5
});

stats.forEach(stat => observer.observe(stat));

// Back to Top Button
const backToTop = document.querySelector('[data-back-to-top]');

window.addEventListener('scroll', () => {
  if (window.pageYOffset > 300) {
    backToTop.classList.add('visible');
  } else {
    backToTop.classList.remove('visible');
  }
});

backToTop?.addEventListener('click', () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});
